#!/usr/bin/env python
import rospy
from std_srvs.srv import Empty

def parameter_config():
    rospy.init_node('parameter_config', anonymous=True)
    red = rospy.get_param('/turtlesim/background_r', 0)
    green = rospy.get_param('/turtlesim/background_g', 0)
    blue = rospy.get_param('/turtlesim/background_b', 0)
    rospy.loginfo("Get Backgroud Color [%d, %d, %d]", red, green, blue)
    
    rospy.set_param("/turtlesim/background_r", 255)
    rospy.set_param("/turtlesim/background_g", 255)
    rospy.set_param("/turtlesim/background_b", 255)
    rospy.loginfo("Set Backgroud Color [255, 255, 255]")
    
    rospy.wait_for_service('/clear')
    try:
        clear_background = rospy.ServiceProxy('/clear', Empty)
        response = clear_background()
        return response
    except rospy.ServiceException as e:
        print("Service call failed: %s" % e)

if __name__ == "__main__":
    parameter_config()
