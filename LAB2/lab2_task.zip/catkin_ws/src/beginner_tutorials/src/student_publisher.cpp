#include <ros/ros.h>
#include "beginner_tutorials/Student.h"
int main(int argc, char **argv) {
  ros::init(argc, argv, "student_publisher");
  ros::NodeHandle n;
  ros::Publisher person_info_pub = n.advertise<beginner_tutorials::Student>("/student_score", 10);
  ros::Rate loop_rate(1);
  while (ros::ok()) {
    beginner_tutorials::Student msg;
    msg.name = "Jimmy";
    msg.id = "12345678";
    msg.grade = 3; 
    msg.score = 90.8;
    person_info_pub.publish(msg);
    ROS_INFO("Publish Student's score name:%s id:%s grade:%d float32:%.2f", msg.name.c_str(), msg.id.c_str(), msg.grade, msg.score);
    loop_rate.sleep();
  }
  return 0;
}
