#include <ros/ros.h>
#include "beginner_tutorials/Student.h"
void studentCallback(const beginner_tutorials::Student::ConstPtr& msg) {
  ROS_INFO("Subcribe Student's score: name:%s id:%s grade:%d score:%.2f", msg->name.c_str(), msg->id.c_str(), msg->grade, msg->score);
}
int main(int argc, char **argv) {
  ros::init(argc, argv, "student_subscriber");
  ros::NodeHandle n;
  ros::Subscriber person_info_sub = n.subscribe("/student_score", 10, studentCallback);
  ros::spin();
  return 0;
}
