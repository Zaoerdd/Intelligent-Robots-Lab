#!/usr/bin/env python
import rospy
from beginner_tutorials.srv import *
def studentCallback(req):
    rospy.loginfo("the student id:%s", req.id)
    return StuScoreResponse("Jimmy", req.id, 3, 95.8)
def student_server():
    rospy.init_node('student_server')
    s = rospy.Service('/student_score', StuScore, studentCallback)
    print("Ready to response student's score.")
    rospy.spin()
if __name__ == "__main__":
    student_server()
