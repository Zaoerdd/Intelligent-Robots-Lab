#!/usr/bin/env python
import rospy
from std_srvs.srv import SetBool, SetBoolResponse
def stringCallback(req):
    if req.data:
        rospy.loginfo("Hello ROS!")
        return SetBoolResponse(True, "Print Successully")
    else:
        return SetBoolResponse(False, "Print Failed")
def string_server():
    rospy.init_node('string_server')
    s = rospy.Service('print_string', SetBool, stringCallback)
    print("Ready to print hello string.")
    rospy.spin()
if __name__ == "__main__":
    string_server()
