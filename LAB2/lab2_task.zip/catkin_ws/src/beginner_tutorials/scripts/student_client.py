#!/usr/bin/env python
import sys
import rospy
from beginner_tutorials.srv import *
def student_client():
    rospy.init_node('student_client')
    rospy.wait_for_service('/student_score')
    try:
        student_client = rospy.ServiceProxy('/student_score', StuScore)
        response = student_client("12345678")
        return response
    except rospy.ServiceException as e:
        print("Service call failed: %s"%e)
if __name__ == "__main__":
    print("Show Student's score:\n%s" % (student_client()))
