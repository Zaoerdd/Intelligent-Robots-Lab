#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import rospy
from lab2_task.srv import TurtleCreate

def create_client(name):
    rospy.init_node('turtle_create_client')
    rospy.wait_for_service('/turtle_create')
    try:
        creator = rospy.ServiceProxy('/turtle_create', TurtleCreate)
        resp = creator(name)
        rospy.loginfo(resp.message)
    except rospy.ServiceException as e:
        rospy.logerr("Service call failed: %s" % e)

if __name__ == "__main__":
    if len(sys.argv) == 2:
        create_client(sys.argv[1])
    else:
        print("Usage: rosrun lab2_task turtle_create_client.py <turtle_name>")
