#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import rospy
from lab2_task.srv import TurtleCommand

def command_client(name, start, v, w):
    rospy.init_node('turtle_command_client')
    rospy.wait_for_service('/turtle_command')
    try:
        commander = rospy.ServiceProxy('/turtle_command', TurtleCommand)
        resp = commander(name, start, v, w)
        rospy.loginfo(resp.message)
    except rospy.ServiceException as e:
        rospy.logerr("Service call failed: %s" % e)

if __name__ == "__main__":
    if len(sys.argv) == 5:
        name = sys.argv[1]
        start = sys.argv[2].lower() in ['true', '1', 't', 'y', 'yes']
        v = float(sys.argv[3])
        w = float(sys.argv[4])
        command_client(name, start, v, w)
    else:
        print("Usage: rosrun lab2_task turtle_command_client.py <turtle_name> <start(true/false)> <linear_vel> <angular_vel>")
