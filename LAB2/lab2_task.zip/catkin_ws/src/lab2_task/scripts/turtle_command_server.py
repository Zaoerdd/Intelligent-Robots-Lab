#!/usr/bin/env python
# -*- coding: utf-8 -*-
import rospy
import random
import math
from turtlesim.srv import Spawn
from geometry_msgs.msg import Twist
from lab2_task.srv import TurtleCreate, TurtleCreateResponse
from lab2_task.srv import TurtleCommand, TurtleCommandResponse

turtles = {}
existing_coords = [(5.54, 5.54)] # 默认第一只海龟在正中央

def get_non_overlapping_pos():
    # 防重叠算法：生成新坐标并检查与已有海龟的距离
    for _ in range(100):
        x = random.uniform(2.0, 9.0)
        y = random.uniform(2.0, 9.0)
        overlap = False
        for ex, ey in existing_coords:
            if math.sqrt((x-ex)**2 + (y-ey)**2) < 1.5: # 距离小于1.5认为重叠
                overlap = True
                break
        if not overlap:
            existing_coords.append((x, y))
            return x, y
    return 2.0, 2.0

def handle_create(req):
    rospy.wait_for_service('/spawn')
    try:
        spawner = rospy.ServiceProxy('/spawn', Spawn)
        x, y = get_non_overlapping_pos()
        theta = random.uniform(0, 3.14)
        spawner(x, y, theta, req.name)
        
        pub = rospy.Publisher('/' + req.name + '/cmd_vel', Twist, queue_size=10)
        turtles[req.name] = {'pub': pub, 'twist': Twist(), 'moving': False}
        return TurtleCreateResponse(True, "Turtle [%s] created successfully at (%.2f, %.2f)!" % (req.name, x, y))
    except rospy.ServiceException as e:
        return TurtleCreateResponse(False, "Failed to spawn: %s" % e)

def handle_command(req):
    if req.name not in turtles:
        pub = rospy.Publisher('/' + req.name + '/cmd_vel', Twist, queue_size=10)
        turtles[req.name] = {'pub': pub, 'twist': Twist(), 'moving': False}
    
    turtles[req.name]['moving'] = req.start
    if req.start:
        turtles[req.name]['twist'].linear.x = req.linear_vel
        turtles[req.name]['twist'].angular.z = req.angular_vel
    else:
        turtles[req.name]['twist'].linear.x = 0.0
        turtles[req.name]['twist'].angular.z = 0.0
        # 立刻停下
        turtles[req.name]['pub'].publish(turtles[req.name]['twist'])
        
    state_str = "STARTED moving" if req.start else "STOPPED"
    return TurtleCommandResponse(True, "Turtle [%s] %s!" % (req.name, state_str))

def server():
    rospy.init_node('turtle_command_server')
    rospy.Service('/turtle_create', TurtleCreate, handle_create)
    rospy.Service('/turtle_command', TurtleCommand, handle_command)
    rospy.loginfo("Bonus Server is Ready! Waiting for clients...")
    
    rate = rospy.Rate(20) # 20Hz 控制循环
    while not rospy.is_shutdown():
        for name, data in turtles.items():
            if data['moving']:
                data['pub'].publish(data['twist'])
        rate.sleep()

if __name__ == "__main__":
    server()
