set(beginner_tutorials_MESSAGE_FILES "/home/zr/catkin_ws/src/beginner_tutorials/msg/Student.msg")
set(beginner_tutorials_SERVICE_FILES "/home/zr/catkin_ws/src/beginner_tutorials/srv/StuScore.srv")
