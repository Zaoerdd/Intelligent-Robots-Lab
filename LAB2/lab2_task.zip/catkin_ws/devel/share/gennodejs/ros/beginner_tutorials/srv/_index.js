
"use strict";

let StuScore = require('./StuScore.js')

module.exports = {
  StuScore: StuScore,
};
