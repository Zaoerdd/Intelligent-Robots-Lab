
"use strict";

let TurtleCreate = require('./TurtleCreate.js')
let TurtleCommand = require('./TurtleCommand.js')

module.exports = {
  TurtleCreate: TurtleCreate,
  TurtleCommand: TurtleCommand,
};
