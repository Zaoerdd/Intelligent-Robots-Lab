# generated from genmsg/cmake/pkg-msg-paths.cmake.develspace.in

set(lab2_task_MSG_INCLUDE_DIRS "")
set(lab2_task_MSG_DEPENDENCIES std_msgs)
