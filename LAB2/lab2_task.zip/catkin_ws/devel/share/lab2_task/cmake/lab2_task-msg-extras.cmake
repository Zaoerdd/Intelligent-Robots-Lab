set(lab2_task_MESSAGE_FILES "")
set(lab2_task_SERVICE_FILES "/home/zr/catkin_ws/src/lab2_task/srv/TurtleCreate.srv;/home/zr/catkin_ws/src/lab2_task/srv/TurtleCommand.srv")
