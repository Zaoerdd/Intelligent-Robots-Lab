(cl:in-package beginner_tutorials-msg)
(cl:export '(NAME-VAL
          NAME
          ID-VAL
          ID
          GRADE-VAL
          GRADE
          SCORE-VAL
          SCORE
))