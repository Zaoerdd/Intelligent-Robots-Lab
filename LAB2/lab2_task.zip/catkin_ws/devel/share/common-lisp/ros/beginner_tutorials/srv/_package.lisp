(cl:defpackage beginner_tutorials-srv
  (:use )
  (:export
   "STUSCORE"
   "<STUSCORE-REQUEST>"
   "STUSCORE-REQUEST"
   "<STUSCORE-RESPONSE>"
   "STUSCORE-RESPONSE"
  ))

