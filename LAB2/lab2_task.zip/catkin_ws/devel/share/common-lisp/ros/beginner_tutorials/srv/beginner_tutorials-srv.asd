
(cl:in-package :asdf)

(defsystem "beginner_tutorials-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "StuScore" :depends-on ("_package_StuScore"))
    (:file "_package_StuScore" :depends-on ("_package"))
  ))