(cl:in-package beginner_tutorials-srv)
(cl:export '(ID-VAL
          ID
          NAME-VAL
          NAME
          ID-VAL
          ID
          GRADE-VAL
          GRADE
          SCORE-VAL
          SCORE
))