; Auto-generated. Do not edit!


(cl:in-package beginner_tutorials-srv)


;//! \htmlinclude StuScore-request.msg.html

(cl:defclass <StuScore-request> (roslisp-msg-protocol:ros-message)
  ((id
    :reader id
    :initarg :id
    :type cl:string
    :initform ""))
)

(cl:defclass StuScore-request (<StuScore-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <StuScore-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'StuScore-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name beginner_tutorials-srv:<StuScore-request> is deprecated: use beginner_tutorials-srv:StuScore-request instead.")))

(cl:ensure-generic-function 'id-val :lambda-list '(m))
(cl:defmethod id-val ((m <StuScore-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader beginner_tutorials-srv:id-val is deprecated.  Use beginner_tutorials-srv:id instead.")
  (id m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <StuScore-request>) ostream)
  "Serializes a message object of type '<StuScore-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'id))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <StuScore-request>) istream)
  "Deserializes a message object of type '<StuScore-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<StuScore-request>)))
  "Returns string type for a service object of type '<StuScore-request>"
  "beginner_tutorials/StuScoreRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'StuScore-request)))
  "Returns string type for a service object of type 'StuScore-request"
  "beginner_tutorials/StuScoreRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<StuScore-request>)))
  "Returns md5sum for a message object of type '<StuScore-request>"
  "6261c31637cbde0972bcdf8209b75f9c")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'StuScore-request)))
  "Returns md5sum for a message object of type 'StuScore-request"
  "6261c31637cbde0972bcdf8209b75f9c")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<StuScore-request>)))
  "Returns full string definition for message of type '<StuScore-request>"
  (cl:format cl:nil "string id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'StuScore-request)))
  "Returns full string definition for message of type 'StuScore-request"
  (cl:format cl:nil "string id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <StuScore-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'id))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <StuScore-request>))
  "Converts a ROS message object to a list"
  (cl:list 'StuScore-request
    (cl:cons ':id (id msg))
))
;//! \htmlinclude StuScore-response.msg.html

(cl:defclass <StuScore-response> (roslisp-msg-protocol:ros-message)
  ((name
    :reader name
    :initarg :name
    :type cl:string
    :initform "")
   (id
    :reader id
    :initarg :id
    :type cl:string
    :initform "")
   (grade
    :reader grade
    :initarg :grade
    :type cl:fixnum
    :initform 0)
   (score
    :reader score
    :initarg :score
    :type cl:float
    :initform 0.0))
)

(cl:defclass StuScore-response (<StuScore-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <StuScore-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'StuScore-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name beginner_tutorials-srv:<StuScore-response> is deprecated: use beginner_tutorials-srv:StuScore-response instead.")))

(cl:ensure-generic-function 'name-val :lambda-list '(m))
(cl:defmethod name-val ((m <StuScore-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader beginner_tutorials-srv:name-val is deprecated.  Use beginner_tutorials-srv:name instead.")
  (name m))

(cl:ensure-generic-function 'id-val :lambda-list '(m))
(cl:defmethod id-val ((m <StuScore-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader beginner_tutorials-srv:id-val is deprecated.  Use beginner_tutorials-srv:id instead.")
  (id m))

(cl:ensure-generic-function 'grade-val :lambda-list '(m))
(cl:defmethod grade-val ((m <StuScore-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader beginner_tutorials-srv:grade-val is deprecated.  Use beginner_tutorials-srv:grade instead.")
  (grade m))

(cl:ensure-generic-function 'score-val :lambda-list '(m))
(cl:defmethod score-val ((m <StuScore-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader beginner_tutorials-srv:score-val is deprecated.  Use beginner_tutorials-srv:score instead.")
  (score m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <StuScore-response>) ostream)
  "Serializes a message object of type '<StuScore-response>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'name))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'id))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'grade)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'score))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <StuScore-response>) istream)
  "Deserializes a message object of type '<StuScore-response>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'grade)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'score) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<StuScore-response>)))
  "Returns string type for a service object of type '<StuScore-response>"
  "beginner_tutorials/StuScoreResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'StuScore-response)))
  "Returns string type for a service object of type 'StuScore-response"
  "beginner_tutorials/StuScoreResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<StuScore-response>)))
  "Returns md5sum for a message object of type '<StuScore-response>"
  "6261c31637cbde0972bcdf8209b75f9c")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'StuScore-response)))
  "Returns md5sum for a message object of type 'StuScore-response"
  "6261c31637cbde0972bcdf8209b75f9c")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<StuScore-response>)))
  "Returns full string definition for message of type '<StuScore-response>"
  (cl:format cl:nil "string name~%string id~%uint8 grade~%float32 score~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'StuScore-response)))
  "Returns full string definition for message of type 'StuScore-response"
  (cl:format cl:nil "string name~%string id~%uint8 grade~%float32 score~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <StuScore-response>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'name))
     4 (cl:length (cl:slot-value msg 'id))
     1
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <StuScore-response>))
  "Converts a ROS message object to a list"
  (cl:list 'StuScore-response
    (cl:cons ':name (name msg))
    (cl:cons ':id (id msg))
    (cl:cons ':grade (grade msg))
    (cl:cons ':score (score msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'StuScore)))
  'StuScore-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'StuScore)))
  'StuScore-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'StuScore)))
  "Returns string type for a service object of type '<StuScore>"
  "beginner_tutorials/StuScore")