
(cl:in-package :asdf)

(defsystem "lab2_task-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "TurtleCommand" :depends-on ("_package_TurtleCommand"))
    (:file "_package_TurtleCommand" :depends-on ("_package"))
    (:file "TurtleCreate" :depends-on ("_package_TurtleCreate"))
    (:file "_package_TurtleCreate" :depends-on ("_package"))
  ))