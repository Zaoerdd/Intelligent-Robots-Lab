(cl:in-package lab2_task-srv)
(cl:export '(NAME-VAL
          NAME
          START-VAL
          START
          LINEAR_VEL-VAL
          LINEAR_VEL
          ANGULAR_VEL-VAL
          ANGULAR_VEL
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))