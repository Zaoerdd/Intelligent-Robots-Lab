; Auto-generated. Do not edit!


(cl:in-package lab2_task-srv)


;//! \htmlinclude TurtleCommand-request.msg.html

(cl:defclass <TurtleCommand-request> (roslisp-msg-protocol:ros-message)
  ((name
    :reader name
    :initarg :name
    :type cl:string
    :initform "")
   (start
    :reader start
    :initarg :start
    :type cl:boolean
    :initform cl:nil)
   (linear_vel
    :reader linear_vel
    :initarg :linear_vel
    :type cl:float
    :initform 0.0)
   (angular_vel
    :reader angular_vel
    :initarg :angular_vel
    :type cl:float
    :initform 0.0))
)

(cl:defclass TurtleCommand-request (<TurtleCommand-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TurtleCommand-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TurtleCommand-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name lab2_task-srv:<TurtleCommand-request> is deprecated: use lab2_task-srv:TurtleCommand-request instead.")))

(cl:ensure-generic-function 'name-val :lambda-list '(m))
(cl:defmethod name-val ((m <TurtleCommand-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader lab2_task-srv:name-val is deprecated.  Use lab2_task-srv:name instead.")
  (name m))

(cl:ensure-generic-function 'start-val :lambda-list '(m))
(cl:defmethod start-val ((m <TurtleCommand-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader lab2_task-srv:start-val is deprecated.  Use lab2_task-srv:start instead.")
  (start m))

(cl:ensure-generic-function 'linear_vel-val :lambda-list '(m))
(cl:defmethod linear_vel-val ((m <TurtleCommand-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader lab2_task-srv:linear_vel-val is deprecated.  Use lab2_task-srv:linear_vel instead.")
  (linear_vel m))

(cl:ensure-generic-function 'angular_vel-val :lambda-list '(m))
(cl:defmethod angular_vel-val ((m <TurtleCommand-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader lab2_task-srv:angular_vel-val is deprecated.  Use lab2_task-srv:angular_vel instead.")
  (angular_vel m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TurtleCommand-request>) ostream)
  "Serializes a message object of type '<TurtleCommand-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'name))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'start) 1 0)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'linear_vel))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'angular_vel))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TurtleCommand-request>) istream)
  "Deserializes a message object of type '<TurtleCommand-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:slot-value msg 'start) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'linear_vel) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'angular_vel) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TurtleCommand-request>)))
  "Returns string type for a service object of type '<TurtleCommand-request>"
  "lab2_task/TurtleCommandRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TurtleCommand-request)))
  "Returns string type for a service object of type 'TurtleCommand-request"
  "lab2_task/TurtleCommandRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TurtleCommand-request>)))
  "Returns md5sum for a message object of type '<TurtleCommand-request>"
  "47434b7ca99e3b8107185bb498d88626")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TurtleCommand-request)))
  "Returns md5sum for a message object of type 'TurtleCommand-request"
  "47434b7ca99e3b8107185bb498d88626")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TurtleCommand-request>)))
  "Returns full string definition for message of type '<TurtleCommand-request>"
  (cl:format cl:nil "string name~%bool start~%float32 linear_vel~%float32 angular_vel~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TurtleCommand-request)))
  "Returns full string definition for message of type 'TurtleCommand-request"
  (cl:format cl:nil "string name~%bool start~%float32 linear_vel~%float32 angular_vel~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TurtleCommand-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'name))
     1
     4
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TurtleCommand-request>))
  "Converts a ROS message object to a list"
  (cl:list 'TurtleCommand-request
    (cl:cons ':name (name msg))
    (cl:cons ':start (start msg))
    (cl:cons ':linear_vel (linear_vel msg))
    (cl:cons ':angular_vel (angular_vel msg))
))
;//! \htmlinclude TurtleCommand-response.msg.html

(cl:defclass <TurtleCommand-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil)
   (message
    :reader message
    :initarg :message
    :type cl:string
    :initform ""))
)

(cl:defclass TurtleCommand-response (<TurtleCommand-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TurtleCommand-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TurtleCommand-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name lab2_task-srv:<TurtleCommand-response> is deprecated: use lab2_task-srv:TurtleCommand-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <TurtleCommand-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader lab2_task-srv:success-val is deprecated.  Use lab2_task-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'message-val :lambda-list '(m))
(cl:defmethod message-val ((m <TurtleCommand-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader lab2_task-srv:message-val is deprecated.  Use lab2_task-srv:message instead.")
  (message m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TurtleCommand-response>) ostream)
  "Serializes a message object of type '<TurtleCommand-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'message))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'message))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TurtleCommand-response>) istream)
  "Deserializes a message object of type '<TurtleCommand-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'message) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'message) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TurtleCommand-response>)))
  "Returns string type for a service object of type '<TurtleCommand-response>"
  "lab2_task/TurtleCommandResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TurtleCommand-response)))
  "Returns string type for a service object of type 'TurtleCommand-response"
  "lab2_task/TurtleCommandResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TurtleCommand-response>)))
  "Returns md5sum for a message object of type '<TurtleCommand-response>"
  "47434b7ca99e3b8107185bb498d88626")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TurtleCommand-response)))
  "Returns md5sum for a message object of type 'TurtleCommand-response"
  "47434b7ca99e3b8107185bb498d88626")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TurtleCommand-response>)))
  "Returns full string definition for message of type '<TurtleCommand-response>"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TurtleCommand-response)))
  "Returns full string definition for message of type 'TurtleCommand-response"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TurtleCommand-response>))
  (cl:+ 0
     1
     4 (cl:length (cl:slot-value msg 'message))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TurtleCommand-response>))
  "Converts a ROS message object to a list"
  (cl:list 'TurtleCommand-response
    (cl:cons ':success (success msg))
    (cl:cons ':message (message msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'TurtleCommand)))
  'TurtleCommand-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'TurtleCommand)))
  'TurtleCommand-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TurtleCommand)))
  "Returns string type for a service object of type '<TurtleCommand>"
  "lab2_task/TurtleCommand")