(cl:in-package lab2_task-srv)
(cl:export '(NAME-VAL
          NAME
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))