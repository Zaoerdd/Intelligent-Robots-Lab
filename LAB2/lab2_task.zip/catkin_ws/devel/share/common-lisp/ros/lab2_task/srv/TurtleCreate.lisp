; Auto-generated. Do not edit!


(cl:in-package lab2_task-srv)


;//! \htmlinclude TurtleCreate-request.msg.html

(cl:defclass <TurtleCreate-request> (roslisp-msg-protocol:ros-message)
  ((name
    :reader name
    :initarg :name
    :type cl:string
    :initform ""))
)

(cl:defclass TurtleCreate-request (<TurtleCreate-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TurtleCreate-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TurtleCreate-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name lab2_task-srv:<TurtleCreate-request> is deprecated: use lab2_task-srv:TurtleCreate-request instead.")))

(cl:ensure-generic-function 'name-val :lambda-list '(m))
(cl:defmethod name-val ((m <TurtleCreate-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader lab2_task-srv:name-val is deprecated.  Use lab2_task-srv:name instead.")
  (name m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TurtleCreate-request>) ostream)
  "Serializes a message object of type '<TurtleCreate-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'name))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TurtleCreate-request>) istream)
  "Deserializes a message object of type '<TurtleCreate-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TurtleCreate-request>)))
  "Returns string type for a service object of type '<TurtleCreate-request>"
  "lab2_task/TurtleCreateRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TurtleCreate-request)))
  "Returns string type for a service object of type 'TurtleCreate-request"
  "lab2_task/TurtleCreateRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TurtleCreate-request>)))
  "Returns md5sum for a message object of type '<TurtleCreate-request>"
  "d82dc6474dd88dad5e1615ab1b2ca74c")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TurtleCreate-request)))
  "Returns md5sum for a message object of type 'TurtleCreate-request"
  "d82dc6474dd88dad5e1615ab1b2ca74c")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TurtleCreate-request>)))
  "Returns full string definition for message of type '<TurtleCreate-request>"
  (cl:format cl:nil "string name~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TurtleCreate-request)))
  "Returns full string definition for message of type 'TurtleCreate-request"
  (cl:format cl:nil "string name~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TurtleCreate-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'name))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TurtleCreate-request>))
  "Converts a ROS message object to a list"
  (cl:list 'TurtleCreate-request
    (cl:cons ':name (name msg))
))
;//! \htmlinclude TurtleCreate-response.msg.html

(cl:defclass <TurtleCreate-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil)
   (message
    :reader message
    :initarg :message
    :type cl:string
    :initform ""))
)

(cl:defclass TurtleCreate-response (<TurtleCreate-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TurtleCreate-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TurtleCreate-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name lab2_task-srv:<TurtleCreate-response> is deprecated: use lab2_task-srv:TurtleCreate-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <TurtleCreate-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader lab2_task-srv:success-val is deprecated.  Use lab2_task-srv:success instead.")
  (success m))

(cl:ensure-generic-function 'message-val :lambda-list '(m))
(cl:defmethod message-val ((m <TurtleCreate-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader lab2_task-srv:message-val is deprecated.  Use lab2_task-srv:message instead.")
  (message m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TurtleCreate-response>) ostream)
  "Serializes a message object of type '<TurtleCreate-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'message))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'message))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TurtleCreate-response>) istream)
  "Deserializes a message object of type '<TurtleCreate-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'message) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'message) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TurtleCreate-response>)))
  "Returns string type for a service object of type '<TurtleCreate-response>"
  "lab2_task/TurtleCreateResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TurtleCreate-response)))
  "Returns string type for a service object of type 'TurtleCreate-response"
  "lab2_task/TurtleCreateResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TurtleCreate-response>)))
  "Returns md5sum for a message object of type '<TurtleCreate-response>"
  "d82dc6474dd88dad5e1615ab1b2ca74c")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TurtleCreate-response)))
  "Returns md5sum for a message object of type 'TurtleCreate-response"
  "d82dc6474dd88dad5e1615ab1b2ca74c")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TurtleCreate-response>)))
  "Returns full string definition for message of type '<TurtleCreate-response>"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TurtleCreate-response)))
  "Returns full string definition for message of type 'TurtleCreate-response"
  (cl:format cl:nil "bool success~%string message~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TurtleCreate-response>))
  (cl:+ 0
     1
     4 (cl:length (cl:slot-value msg 'message))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TurtleCreate-response>))
  "Converts a ROS message object to a list"
  (cl:list 'TurtleCreate-response
    (cl:cons ':success (success msg))
    (cl:cons ':message (message msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'TurtleCreate)))
  'TurtleCreate-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'TurtleCreate)))
  'TurtleCreate-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TurtleCreate)))
  "Returns string type for a service object of type '<TurtleCreate>"
  "lab2_task/TurtleCreate")